//Brandon Pollack
//2375-4365

struct ChainNode
{
	int data;
	ChainNode* nextNode;
};
