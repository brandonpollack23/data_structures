
#include <iostream>
#include "Chain.h"
#include "IOcode.h"

using namespace std;

int main ()
{

	Chain *myChain=new Chain();
	userInputOutput(myChain, "chain");
}
