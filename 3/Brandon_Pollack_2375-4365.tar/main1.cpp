
#include <iostream>
#include "Arraylist.h"
#include "IOcode.h"

using namespace std;

int main (){

	arrayList *myList=new arrayList(10);
	userInputOutput(myList, "Arraylist");
}
