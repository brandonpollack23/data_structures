//Brandon Pollack
//2375-4365
#include "BinaryTree.h"

BinaryTree::BinaryTree()
{
	root = new Node();
}